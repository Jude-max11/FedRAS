# FedRAS Code Package — Deadline-Aware Rank Scheduling for Federated LoRA in Mobile Edge Networks

Code for the experiments in the FedRAS manuscript: a real-byte PyTorch
trainer for deadline-aware adaptive-rank federated LoRA fine-tuning, a
500-client federated scheduling simulator, solver/robustness/calibration
studies, and the analysis and figure scripts that produce every table and
figure in the paper from the run outputs.

> **Naming**: the mechanism called **FedRAS** in the paper corresponds to the
> method key `Adaptive_rank` in the code and CSV columns (keys kept unchanged
> so that the data files remain byte-identical with the recorded runs).

## 1. Layout

```
scripts/           training, simulation, analysis, and figure scripts
fedlora/           500-client federated scheduling simulator package
                   (run_experiment.py; invoked as `fedlora/run_experiment.py`)
README.md          this file
requirements.txt   Python dependencies for analysis and figures
```

## 2. Environment

- Python 3.10+; PyTorch 2.x with torchvision (install a CUDA-matched build
  from pytorch.org first), then `pip install -r requirements.txt`
  (numpy, pandas, scipy, matplotlib, PyYAML, scikit-learn).
- Training was performed on one NVIDIA A800 80GB GPU (bf16 autocast).
  Everything also runs on CPU at much higher cost; analysis and figures
  need no GPU.
- Training data: CIFAR-10 / CIFAR-100 / MNIST via `torchvision.datasets`,
  downloaded automatically into `./data` on first use (not shipped).
- Every run writes `config.json` (all hyperparameters) and `metrics.csv`
  (per round: accuracy, timely_ratio, bytes_mb, mean_rank, selected,
  aggregated, update_norm).

Runner scripts pick the interpreter from `PY` if set, otherwise `python3`
from `PATH` (`run_real_v3.sh` and `run_v4_matrix.sh` take the interpreter
as an optional positional argument). All paths are relative to the package
root; run commands from the extracted directory.

## 3. What was run (experiment matrix)

| Run set | Script | Seeds | Output |
|---|---|---|---|
| v4 real-byte trainer matrix (phases A–D: deadlines, baselines/DP arms/ablations, 10-seed extension + cross-dataset + sensitivity, solver/simulator/calibration) | `scripts/run_v4_matrix.sh A\|B\|C\|D` | 0–9 | `outputs/real_fedlora_v4/` |
| Aggregate v4 runs into one table | `python scripts/assemble_v4.py --root outputs/real_fedlora_v4` | — | `outputs/real_fedlora_v4/all_metrics.csv` |
| FP16-upload arm of FedRAS | `scripts/run_fedras_fp16.sh` | 0–4 | `outputs/real_fedlora_v4/fedras_fp16*` |
| Weak-backbone capacity-payoff runs | `scripts/run_weak_catchup.sh` | 0–4 | `outputs/real_fedlora_v4/weakbb*` |
| Delivered-update norm vs rank runs | `scripts/run_norm_curve.sh` | 0–4 | `outputs/real_fedlora_v4/normcurve*` |
| v3 trainer matrix (23 configurations × 5 methods) | `scripts/run_real_v3.sh` | 0–4 | `outputs/real_fedlora_v3/all_metrics.csv` |
| Ten-seed replication of the headline regimes | `scripts/wcnc_run_seeds59.sh` | 5–9 | `outputs/wcnc_extra/real_v3_ext*` |
| Full-DP scheduler arm and external baselines to ten seeds | `scripts/journal_dp_runs.sh` | 0–9 | `outputs/journal_dp/`, `outputs/journal_ext/` |
| Extra DP trainer replication | `scripts/wcnc_run_dp_trainer.sh` | 5–9 | `outputs/wcnc_extra/real_v3_dp/` |
| Stress / external / ablation runners (v3 era) | `scripts/run_stress_v3.sh`, `run_ext_v3.sh`, `run_abl2_v3.sh` | 0–4 | `outputs/real_fedlora_v3*/` |
| 500-client scheduling simulation, nine regimes | `scripts/run_sweep.py` → `fedlora/run_experiment.py` | 0–4 | `outputs/paper_sweep/` |
| Solver study (exact DP vs greedy, 30 instances/cell) | `scripts/dp_scheduler_study.py --grid-sweep` | — | `outputs/dp_scheduler_study.csv` |
| Budget-grid sensitivity sweep | `scripts/wcnc_grid_sensitivity.py` | — | `outputs/wcnc_extra/grid_sensitivity.csv` |
| Predictor / utility-form robustness | `scripts/wcnc_scheduler_robustness.py` | — | `outputs/wcnc_extra/scheduler_robustness.csv` |

`v4_watchdog.sh` / `v4_watchdog_c.sh` re-invoke the v4 matrix with
checkpoint-aware skip logic, so interrupted phases can simply be resumed.

Common random numbers: link traces (rate ~ LogNormal(2.5, 0.7) clipped to
[1, 40] Mbps; mobility ~ Beta(2, 5)) are seeded per (seed, round) and shared
across methods; backbone weights are cached per seed and reused for the
deadline-stress and DP arms (copied `backbone_*` files, fingerprint-checked).

## 4. Reproducing tables and figures

| Paper element | Command |
|---|---|
| Every v4 journal-paper number (trainer, stress, extended, external baselines, DP arms, sensitivity) | `python scripts/print_v4_tables.py` |
| Manuscript figures from v4 data (trainer/simulator/DP/sensitivity/normlaw/weakbb panels) | `python scripts/make_v4_figs_submission.py`, `make_normlaw_fig.py`, `make_weakbb_fig.py` → `outputs/figures/` |
| FedRAS system-architecture schematic | `python scripts/make_fedras_architecture.py` |
| Split combined figure PDFs into per-panel pieces | `python scripts/split_fedras_panels.py <in> <out>` (requires pymupdf) |
| Trainer tables (accuracy parity, deadline stress, extended matrix) | `python scripts/summarize_real_fedlora.py --root outputs/real_fedlora_v3` |
| External-baseline and DP-vs-fair-cohort tables, ten-seed paired statistics | `python scripts/journal_baseline_stats.py`, `journal_dp_compare.py`, `journal_stats.py` |
| Calibration study (reliability curves, ECE) | `python scripts/journal_calibration.py` |
| Model / payload audit | `python scripts/journal_model_audit.py` |
| Five-seed paired tests | `python scripts/stat_tests.py` |
| Solver table (optimality gaps, runtime) | `python scripts/dp_scheduler_study.py` |
| Simulator tables/figures | `python scripts/run_sweep.py`, then `collect_sweep.py`, `plot_sweep.py`, `summarize_fedlora.py` |
| v3-era paper figures | `python scripts/make_paper_figs.py`, `make_more_figs.py`, `make_sensitivity_fig.py` |
| Budget-grid discretization error / robustness | `python scripts/wcnc_grid_sensitivity.py`, `wcnc_scheduler_robustness.py` |

Analysis outputs land under `outputs/journal_stats/` and `outputs/figures/`.

## 5. Rerunning training

Example — one seed of the full main configuration (nominal 2.0 s deadline):

```
python scripts/train_torch_fedlora.py --data data --dataset cifar10 \
  --out outputs/real_fedlora_v4/cifar10_seed0 \
  --rounds 40 --clients 20 --pretrain-epochs 30 --seed 0 --deadline 2.0
```

Full-DP arm:

```
python scripts/train_torch_fedlora.py --data data --dataset cifar10 \
  --out outputs/journal_dp/dp_seed0 \
  --rounds 40 --clients 20 --pretrain-epochs 30 --seed 0 \
  --methods DP_cohort --no-full-baseline --dp-budget 8.2
```

Approximate cost per seed on one A800: 15–25 min for the five-method main
set, 5–10 min for the DP arm, 20–30 min for the three-baseline set; central
backbone pretraining (30 epochs, ~10 min) is cached per seed and reused
across deadline settings.

## 6. Provenance

- All tables in the manuscript are transcriptions of the CSV outputs of the
  scripts above; `print_v4_tables.py` regenerates every v4 number from the
  per-run `metrics.csv` files.
- This package intentionally ships **code only**: no datasets, no model
  checkpoints (`*.pt`), and no result files. The aggregated result tables
  and per-run metrics underlying the manuscript are available from the
  authors on request; every figure and table can be regenerated from a
  completed run directory without GPU access.
