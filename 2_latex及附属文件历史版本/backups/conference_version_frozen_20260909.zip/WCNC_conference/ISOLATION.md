# 版本隔离说明（会议版 ↔ 期刊版）

本文档说明两个论文版本之间的隔离机制，以及今后分别修改时的操作规则。

## 隔离模型总览

| 资源 | 会议版（`WCNC_conference/`） | 期刊版（`FedLoRA lunwen/`） | 是否隔离 |
|---|---|---|---|
| 正文 | `main.tex`（IEEEtran） | `main_lora_clean.tex`（elsarticle） | ✅ 各自独立文件 |
| 参考文献 | `references.bib`（本地副本，19 条被引用） | `references.bib`（31+ 条） | ✅ 独立副本，互不影响 |
| 实验图 PNG | `fig_trainer_stress.png`、`fig_sim_stress.png`（本文件夹内） | `trainer_*.png`、`sim_*.png` 等 | ✅ 独立副本 |
| TikZ 矢量图 | `main.tex` 内嵌（Fig. 1/2） | `main_lora_clean.tex` 内嵌 | ✅ 各自源文件内 |
| 图片生成脚本 | `make_wcnc_figs.py`（**只读本文件夹 `data_snapshot/`**） | `scripts/make_paper_figs.py`（写 `FedLoRA lunwen/`） | ✅ 读写路径互不相交 |
| 实验数据 | `data_snapshot/`（**冻结快照**） | `../outputs/`（活的实验输出） | ✅ 会议版不再读取 `outputs/` |
| 编译产物 | `main.pdf/aux/bbl/...` | `main_lora_clean.pdf/...` | ✅ 各自文件夹内 |

## 数据快照溯源（data_snapshot/）

快照时间：2026-09-08。SHA256 与源文件比对一致，重生成的图与快照前逐像素一致。

| 快照文件 | 来源 | SHA256（前 16 位） |
|---|---|---|
| `real_fedlora_v3__all_metrics.csv` | `outputs/real_fedlora_v3/all_metrics.csv` | `0ab14341cfb2fd25` |
| `paper_sweep__all_round_metrics.csv` | `outputs/paper_sweep/all_round_metrics.csv` | `50f4e260d250fb22` |

## 今后的操作规则

### 修改会议版（不影响期刊版）
- 直接编辑 `WCNC_conference/` 内任何文件，随意改图、改数据快照、重编译。
- 会议版**唯一对外读取路径已清零**，怎么改都不会波及期刊版。
- 若要用新实验结果更新会议图：把新 CSV 复制进 `data_snapshot/`（覆盖前建议核对口径），再 `python make_wcnc_figs.py && pdflatex main && bibtex main && pdflatex main && pdflatex main`。

### 修改期刊版（不影响会议版）
- 编辑 `FedLoRA lunwen/main_lora_clean.tex`、其 `references.bib`、重新生成该文件夹内的 PNG，随便改。
- 重新跑实验、更新 `outputs/`：**会议版不会受任何影响**（它只读自己的快照）。
- 期刊版重新生成图片用的是 `scripts/make_paper_figs.py`，它只写 `FedLoRA lunwen/`，不会碰 `WCNC_conference/`。

## 期刊版遗留问题备忘（修改期刊版前必读）

1. **`FedLoRA lunwen/trainer_dl025.png` 是旧数据批次**：其 y 轴约 0.929–0.932，与正文/表格的 0.914 矛盾
   （会议版发现后已用 `all_metrics.csv` 的 `cifar10_dl0.25` 数据重制）。改期刊版时应同样替换该图，
   正确数据源：`outputs/real_fedlora_v3/all_metrics.csv`，dataset = `cifar10_dl0.25`。
2. **期刊正文 0.24 vs 表格 0.28 口径混用**：期刊版 Q2 段落的 "0.24 (nominal)" 是全程 40 轮平均，
   而表 I 是 30–39 轮窗口平均（0.28）；随后的 "lose 46%/83%" 也基于 0.24。改期刊版时建议统一口径
   （会议版的修法：正文锚定表 I 的 0.28，百分比改为 54%/86%，见 `WCNC_conference/main.tex`）。
3. 期刊版 `references.bib` 含未被引用的条目（如 `mcmahan2017communication`、`lai2021oort` 等），无害但可清理。

## 冻结备份

`../backups/` 下有本轮隔离完成时两个版本的 zip 快照（含日期），即使误改也可整体回滚。
