import argparse, csv, os
import numpy as np

METHODS=['FedAvg','FedLoRA_r4','FedLoRA_r16','Random_rank','Reliability_only','Adaptive_rank']
def run(seed, rounds, clients, ranks, budget, cap, deadline, out, mobility_shape=2.0):
    rng=np.random.default_rng(seed); rows=[]; acc={m:0.10 for m in METHODS};
    # Common random numbers: every method sees identical states in each round.
    traces=[(np.clip(rng.lognormal(2.5,0.7,clients),1,40),
             rng.beta(mobility_shape,5,clients), rng.uniform(0.15,0.45,clients)) for _ in range(rounds)]
    for t in range(rounds):
        rate,mobility,base=traces[t]
        for m in METHODS:
            if m=='FedAvg': rr=np.full(clients,64)
            elif m=='FedLoRA_r4': rr=np.full(clients,4)
            elif m=='FedLoRA_r16': rr=np.full(clients,16)
            elif m=='Random_rank': rr=rng.choice(ranks,clients)
            elif m=='Reliability_only': rr=np.full(clients,4)
            else:
                score=[]
                for r in ranks:
                    size=0.02*r+0.5; p=np.exp(-mobility)*np.exp(-size/(rate*deadline)); score.append(base*p)
                rr=np.array([ranks[int(np.argmax([base[i]*np.exp(-mobility[i])*np.exp(-(0.02*r+0.5)/(rate[i]*deadline)) for r in ranks]))] for i in range(clients)])
            size=0.02*rr+0.5; p=np.exp(-mobility)*np.exp(-size/(rate*deadline)); utility=base*p
            order=np.argsort(-utility); sel=[]; used=0
            for i in order:
                if len(sel)>=cap or used+size[i]>budget: continue
                sel.append(i); used+=size[i]
            timely=float(np.mean(p[sel])) if sel else 0.; gain=float(np.mean(utility[sel])) if sel else 0.
            noise=np.random.default_rng(seed*100000+t*100+METHODS.index(m)).normal(0,0.0005)
            acc[m]+=0.015*gain-0.0002*acc[m]+noise
            rows.append([seed,t,m,acc[m],timely,used,len(sel),float(np.mean(rr[sel])) if sel else 0.,gain])
    os.makedirs(out,exist_ok=True)
    with open(os.path.join(out,f'round_metrics_seed{seed}.csv'),'w',newline='') as f:
        w=csv.writer(f); w.writerow(['seed','round','method','accuracy','timely_ratio','bytes_norm','selected','mean_rank','useful_update_value']); w.writerows(rows)
def main():
    p=argparse.ArgumentParser(); p.add_argument('--out',default='outputs/fedlora'); p.add_argument('--seeds',default='0,1,2,3,4'); p.add_argument('--rounds',type=int,default=150); p.add_argument('--clients',type=int,default=500); p.add_argument('--budget',type=float,default=300); p.add_argument('--cap',type=int,default=25); p.add_argument('--deadline',type=float,default=1.0); p.add_argument('--mobility-shape',type=float,default=2.0); a=p.parse_args();
    for s in map(int,a.seeds.split(',')): run(s,a.rounds,a.clients,[2,4,8,16],a.budget,a.cap,a.deadline,a.out,a.mobility_shape)
if __name__=='__main__': main()
