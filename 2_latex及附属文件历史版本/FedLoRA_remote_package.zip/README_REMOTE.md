# Deadline-aware Adaptive-rank FedLoRA remote package

This package is self-contained and CPU-runnable. It implements the experiment used to populate the manuscript's FedLoRA comparison table. No dataset download or GPU is required: the simulator uses non-IID client contribution proxies and time-correlated mobile-link states so that rank-dependent communication and deadline delivery can be audited.

## Run

```bash
python -m pip install -r requirements.txt
python scripts/run_fedlora.py --out outputs/fedlora --seeds 0,1,2,3,4 --rounds 150 --clients 500 --budget 300 --cap 25 --deadline 1.0
python scripts/summarize_fedlora.py --root outputs/fedlora
```

The primary output is `summary.csv`; per-seed traces are `round_metrics_seed*.csv`. Preserve the complete output directory when returning results.

## Paper-scale sweep (recommended)

```bash
python scripts/run_sweep.py --root outputs/paper_sweep --rounds 150 --seeds 0,1,2,3,4
python scripts/collect_sweep.py --root outputs/paper_sweep
python scripts/plot_sweep.py --root outputs/paper_sweep
```

This runs main CIFAR-10, a CIFAR-100 proxy configuration, a 1000-client scalability configuration, and deadline/budget stress scenarios. The simulator keeps the same deterministic client/link generation protocol across methods and seeds. The output contains `all_round_metrics.csv`, `sweep_summary.csv`, and a `figures/` directory. The CIFAR-100 and MNIST names denote experimental configurations in this lightweight package; for final manuscript claims they should be replaced or cross-validated with actual dataset loaders if real training is required.

Important validity note: this package is a controlled network-scheduler simulator, not a PyTorch LoRA trainer. Use it to validate the client--rank scheduling hypothesis and network metrics. Do not present the proxy accuracy numbers as results on CIFAR-10/CIFAR-100/MNIST until a real dataset loader and LoRA model have been run. All methods now share common random-number link traces within each seed; the mobility stress uses a separate mobility distribution.

## Real PyTorch FedLoRA training

The package also includes `scripts/train_torch_fedlora.py`, a genuine LoRA adapter trainer using torchvision datasets and federated weighted aggregation. It requires a local dataset directory containing the already extracted torchvision files; downloads are disabled for reproducibility. Example:

```bash
python -m pip install torch torchvision pandas numpy matplotlib
python scripts/train_torch_fedlora.py --data /data/cifar --dataset cifar10 --out outputs/real_fedlora/cifar10 --rounds 30 --clients 20 --per-round 5 --device auto
python scripts/train_torch_fedlora.py --data /data/cifar --dataset cifar100 --out outputs/real_fedlora/cifar100 --rounds 30 --clients 20 --per-round 5 --device auto
python scripts/train_torch_fedlora.py --data /data/mnist --dataset mnist --out outputs/real_fedlora/mnist --rounds 30 --clients 20 --per-round 5 --device auto
```

The real trainer writes one CSV per dataset and seed with test accuracy, timely-update ratio, normalized transmitted bytes and rank metadata. Run five seeds (`--seed 0` through `--seed 4`) and preserve the complete output directory. This is the experiment suitable for manuscript claims; the CPU simulator remains useful for rapid stress sweeps.

The trainer first performs a deterministic centralized backbone pretraining stage (`--pretrain-epochs`, default 2), saves `backbone_pretrained.pt`, then freezes the backbone and performs federated LoRA training. This avoids the invalid random-frozen-feature setup. Client models always use `rmax=16`; lower ranks are masked before weighted aggregation. Use `--resume` to continue from `checkpoint.pt`.

## Reproducibility

All random states are seeded. The methods use identical client states and random traces within each seed. `Adaptive_rank` chooses among ranks {2,4,8,16} using the expected timely useful-update objective. `FedAvg` is represented as a full-parameter 64-rank update for communication comparison. This is a scheduler experiment, not a claim of formal privacy.

## Stress sweeps

Repeat the command with `--deadline 0.5`, `--deadline 2.0`, different `--budget`, `--clients`, and `--cap`. Keep one output directory per setting.
