import argparse,csv,json,os,random
import numpy as np, torch
from torch import nn
from torch.utils.data import DataLoader,Subset
from torchvision import datasets,transforms
class LoRALinear(nn.Module):
 def __init__(self,base,rmax=16):
  super().__init__(); self.base=base; self.rmax=rmax
  for p in base.parameters(): p.requires_grad=False
  self.A=nn.Parameter(torch.randn(rmax,base.in_features)*.01); self.B=nn.Parameter(torch.zeros(base.out_features,rmax))
 def forward(self,x): return self.base(x)+(x@self.A.t())@self.B.t()
class Net(nn.Module):
 def __init__(self,c,d,rmax=16): super().__init__(); self.feat=nn.Sequential(nn.Flatten(),nn.Linear(d,128),nn.ReLU()); self.fc=LoRALinear(nn.Linear(128,c),rmax)
 def forward(self,x): return self.fc(self.feat(x))
def pretrain_backbone(model,ds,device,epochs,lr,batch):
 model.train(); opt=torch.optim.SGD(model.parameters(),lr=lr)
 for p in model.fc.base.parameters(): p.requires_grad=True
 for _ in range(epochs):
  for x,y in DataLoader(ds,batch,shuffle=True):
   opt.zero_grad(); nn.functional.cross_entropy(model(x.to(device)),y.to(device)).backward(); opt.step()
 for p in model.fc.base.parameters(): p.requires_grad=False
def ls(m): return {k:v.detach().cpu().clone() for k,v in m.state_dict().items() if k.endswith('.A') or k.endswith('.B')}
def load(m,s):
 z=m.state_dict()
 for k,v in s.items(): z[k].copy_(v)
 m.load_state_dict(z)
def load_base(m,s):
 z=m.state_dict()
 for k,v in s.items():
  if k in z: z[k].copy_(v)
 m.load_state_dict(z)
def avg(ss,ww,rr):
 o={}; den=sum(ww)
 for k in ss[0]:
  z=torch.zeros_like(ss[0][k])
  for s,w,r in zip(ss,ww,rr):
   v=s[k].clone()
   if k.endswith('.A'): v[r:,:]=0
   if k.endswith('.B'): v[:,r:]=0
   z+=w*v
  o[k]=z/den
 return o
def parts(y,n,seed,a):
 g=np.random.default_rng(seed); out=[[] for _ in range(n)]
 for c in np.unique(y):
  ids=np.where(np.asarray(y)==c)[0]; g.shuffle(ids); cuts=(np.cumsum(g.dirichlet(np.full(n,a)))*len(ids)).astype(int)[:-1]
  for j,x in enumerate(np.split(ids,cuts)): out[j]+=x.tolist()
 return [np.asarray(x) for x in out]
def ev(m,ds,d):
 m.eval(); n=o=0
 with torch.no_grad():
  for x,y in DataLoader(ds,256): o+=(m(x.to(d)).argmax(1).cpu()==y).sum().item(); n+=len(y)
 return o/max(1,n)
def main():
 p=argparse.ArgumentParser(); p.add_argument('--data',required=True); p.add_argument('--dataset',choices=['cifar10','cifar100','mnist'],default='cifar10'); p.add_argument('--out',default='outputs/real_fedlora'); p.add_argument('--rounds',type=int,default=30); p.add_argument('--clients',type=int,default=20); p.add_argument('--per-round',type=int,default=5); p.add_argument('--local-epochs',type=int,default=1); p.add_argument('--pretrain-epochs',type=int,default=2); p.add_argument('--batch-size',type=int,default=64); p.add_argument('--lr',type=float,default=.05); p.add_argument('--seed',type=int,default=0); p.add_argument('--alpha',type=float,default=.5); p.add_argument('--resume',action='store_true'); p.add_argument('--device',default='auto'); a=p.parse_args()
 torch.manual_seed(a.seed); np.random.seed(a.seed); random.seed(a.seed); d=torch.device('cuda' if a.device=='auto' and torch.cuda.is_available() else 'cpu'); os.makedirs(a.out,exist_ok=True); mn=a.dataset=='mnist'; c=100 if a.dataset=='cifar100' else 10; dim=784 if mn else 3072; tf=transforms.Compose([transforms.ToTensor(),transforms.Normalize((.5,)* (1 if mn else 3),(.5,)*(1 if mn else 3))]); DS=datasets.MNIST if mn else (datasets.CIFAR100 if a.dataset=='cifar100' else datasets.CIFAR10); tr=DS(a.data,train=True,download=False,transform=tf); te=DS(a.data,train=False,download=False,transform=tf); pp=parts(tr.targets,a.clients,a.seed,a.alpha)
 m=Net(c,dim).to(d); pre=os.path.join(a.out,'backbone_pretrained.pt');
 if os.path.exists(pre): m.load_state_dict(torch.load(pre,map_location=d))
 else: pretrain_backbone(m,tr,d,a.pretrain_epochs,a.lr,a.batch_size); torch.save(m.state_dict(),pre)
 base_state={k:v.detach().cpu().clone() for k,v in m.state_dict().items() if k.startswith('fc.base.')}; initial_state=ls(m); methods=['FedLoRA_r4','FedLoRA_r16','Random_rank','Adaptive_rank']; method_states={x:{k:v.clone() for k,v in initial_state.items()} for x in methods}; ck=os.path.join(a.out,'checkpoint.pt'); start=0
 if a.resume and os.path.exists(ck):
  z=torch.load(ck,map_location=d); m.load_state_dict(z['model']); method_states=z['method_states']; start=z['round']+1
 with open(os.path.join(a.out,'config.json'),'w') as f: json.dump(vars(a)|{'rmax':16,'ranks':[2,4,8,16],'device':str(d),'backbone_pretrained':True},f,indent=2)
 fn=os.path.join(a.out,'metrics.csv'); f=open(fn,'a' if start else 'w',newline=''); w=csv.writer(f); w.writerow(['seed','round','method','accuracy','timely_ratio','bytes_norm','mean_rank','selected','aggregated']) if not start else None
 for rnd in range(start,a.rounds):
  for method in methods:
   g=np.random.default_rng(a.seed*10000+rnd); rate=np.clip(g.lognormal(2.5,.7,a.clients),1,40); mob=g.beta(2,5,a.clients); ch=g.choice(a.clients,min(a.per_round,a.clients),replace=False); ss=[]; ww=[]; rr=[]; used=ok=0
   for i in ch:
    ranks=[2,4,8,16]; r=4 if method=='FedLoRA_r4' else 16 if method=='FedLoRA_r16' else int(g.choice(ranks)) if method=='Random_rank' else ranks[int(np.argmax([np.exp(-mob[i])*np.exp(-(0.02*q+.5)/rate[i]) for q in ranks]))]; local=Net(c,dim).to(d); load_base(local,base_state); load(local,method_states[method]); opt=torch.optim.SGD([local.fc.A,local.fc.B],lr=a.lr); dl=DataLoader(Subset(tr,pp[i]),a.batch_size,shuffle=True); local.train()
    for _ in range(a.local_epochs):
     for x,y in dl: opt.zero_grad(); nn.functional.cross_entropy(local(x.to(d)),y.to(d)).backward(); opt.step()
    size=.02*r+.5; used+=size; pon=np.exp(-mob[i])*np.exp(-size/rate[i]);
    if g.random()<pon: ss.append(ls(local)); ww.append(len(pp[i])); rr.append(r); ok+=1
   if ss: method_states[method]=avg(ss,ww,rr)
   load(m,method_states[method]); w.writerow([a.seed,rnd,method,ev(m,te,d),ok/max(1,len(ch)),used,float(np.mean(rr) if rr else 0),len(ch),len(ss)]); f.flush()
  torch.save({'round':rnd,'model':m.state_dict(),'method_states':method_states},ck)
 f.close()
if __name__=='__main__': main()
