# Submission-evidence report

Positive paired differences favor GCDP. A 95% interval excluding zero is descriptive evidence under the five-seed design; it is not a substitute for an attack-based privacy evaluation.

## exposure_weight_high

| Baseline | Metric | GCDP - baseline | 95% CI |
|---|---|---:|---|
| compression_only | final_accuracy | -0.0105 | [-0.018053, -0.002947] |
| compression_only | mean_objective | 2.5372 | [2.4126, 2.6617] |
| compression_only | success_ratio | 0.026667 | [-0.027289, 0.080622] |
| compression_only | bytes_ratio | -1.41 | [-1.5372, -1.2828] |
| compression_only | brier | -0.014103 | [-0.051813, 0.023607] |
| compression_only | ece | -0.014687 | [-0.062155, 0.03278] |
| fedavg | final_accuracy | 0.62883 | [0.55143, 0.70624] |
| fedavg | mean_objective | 3.3205 | [3.1382, 3.5029] |
| fedavg | success_ratio | 0.85333 | [0.74946, 0.9572] |
| fedavg | bytes_ratio | 2.34 | [2.2128, 2.4672] |
| fedavg | brier | nan | [nan, nan] |
| fedavg | ece | nan | [nan, nan] |
| fixed_aead | final_accuracy | -0.0085 | [-0.01756, 0.00056047] |
| fixed_aead | mean_objective | 3.8253 | [3.4409, 4.2098] |
| fixed_aead | success_ratio | -0.02 | [-0.082759, 0.042759] |
| fixed_aead | bytes_ratio | -27.66 | [-27.787, -27.533] |
| fixed_aead | brier | 0.01534 | [-0.024198, 0.054879] |
| fixed_aead | ece | 0.016667 | [-0.047643, 0.080976] |
| fixed_secagg | final_accuracy | -0.011167 | [-0.016052, -0.0062812] |
| fixed_secagg | mean_objective | 0.28927 | [0.13196, 0.44658] |
| fixed_secagg | success_ratio | 0.013333 | [-0.042187, 0.068853] |
| fixed_secagg | bytes_ratio | -1.41 | [-1.5372, -1.2828] |
| fixed_secagg | brier | -0.0076286 | [-0.049101, 0.033843] |
| fixed_secagg | ece | -0.013646 | [-0.029939, 0.0026472] |
| greedy_repair | final_accuracy | 0 | [0, 0] |
| greedy_repair | mean_objective | 0 | [0, 0] |
| greedy_repair | success_ratio | 0 | [0, 0] |
| greedy_repair | bytes_ratio | 0 | [0, 0] |
| greedy_repair | brier | 0 | [0, 0] |
| greedy_repair | ece | 0 | [0, 0] |
| reactive | final_accuracy | -0.0063333 | [-0.011981, -0.00068577] |
| reactive | mean_objective | 2.486 | [2.3606, 2.6114] |
| reactive | success_ratio | -0.016683 | [-0.074869, 0.041504] |
| reactive | bytes_ratio | -1.065 | [-2.1919, 0.06189] |
| reactive | brier | 0.0096869 | [-0.020823, 0.040197] |
| reactive | ece | -0.014919 | [-0.058945, 0.029107] |
| two_stage | final_accuracy | -0.0031667 | [-0.018519, 0.012185] |
| two_stage | mean_objective | -0.0066534 | [-0.13627, 0.12297] |
| two_stage | success_ratio | -6.6613e-17 | [-0.050683, 0.050683] |
| two_stage | bytes_ratio | -0.1 | [-0.21613, 0.016128] |
| two_stage | brier | -0.0018449 | [-0.040102, 0.036412] |
| two_stage | ece | -0.013854 | [-0.042861, 0.015153] |

## high_exposure_budget

| Baseline | Metric | GCDP - baseline | 95% CI |
|---|---|---:|---|
| compression_only | final_accuracy | -0.00066667 | [-0.015213, 0.01388] |
| compression_only | mean_objective | 1.2434 | [1.1224, 1.3644] |
| compression_only | success_ratio | 0.02 | [-0.03552, 0.07552] |
| compression_only | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| compression_only | brier | -0.011937 | [-0.05872, 0.034847] |
| compression_only | ece | -0.011146 | [-0.058168, 0.035877] |
| fedavg | final_accuracy | 0.63867 | [0.56501, 0.71232] |
| fedavg | mean_objective | 3.5268 | [3.3528, 3.7007] |
| fedavg | success_ratio | 0.84667 | [0.71386, 0.97948] |
| fedavg | bytes_ratio | 2.99 | [2.8178, 3.1622] |
| fedavg | brier | nan | [nan, nan] |
| fedavg | ece | nan | [nan, nan] |
| fixed_aead | final_accuracy | 0.0013333 | [-0.017835, 0.020502] |
| fixed_aead | mean_objective | 2.5315 | [2.1564, 2.9067] |
| fixed_aead | success_ratio | -0.026667 | [-0.11638, 0.063048] |
| fixed_aead | bytes_ratio | -27.01 | [-27.182, -26.838] |
| fixed_aead | brier | 0.017507 | [-0.043605, 0.078618] |
| fixed_aead | ece | 0.020208 | [-0.053878, 0.094295] |
| fixed_secagg | final_accuracy | -0.0013333 | [-0.012418, 0.0097514] |
| fixed_secagg | mean_objective | 0.12142 | [-0.034109, 0.27695] |
| fixed_secagg | success_ratio | 0.0066667 | [-0.061331, 0.074665] |
| fixed_secagg | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| fixed_secagg | brier | -0.0054622 | [-0.062813, 0.051888] |
| fixed_secagg | ece | -0.010104 | [-0.037276, 0.017068] |
| greedy_repair | final_accuracy | 0.0031667 | [-0.005624, 0.011957] |
| greedy_repair | mean_objective | 0.00030337 | [-0.00053878, 0.0011455] |
| greedy_repair | success_ratio | 0.0066667 | [-0.01184, 0.025173] |
| greedy_repair | bytes_ratio | 0.01 | [-0.01776, 0.03776] |
| greedy_repair | brier | -0.0047416 | [-0.017904, 0.0084211] |
| greedy_repair | ece | 0.0025521 | [-0.0045325, 0.0096367] |
| reactive | final_accuracy | -0.00083333 | [-0.016108, 0.014442] |
| reactive | mean_objective | 1.2333 | [1.1083, 1.3584] |
| reactive | success_ratio | 0.026667 | [-0.027289, 0.080622] |
| reactive | bytes_ratio | -1.39 | [-1.8358, -0.94422] |
| reactive | brier | -0.017871 | [-0.061488, 0.025745] |
| reactive | ece | -0.016562 | [-0.053682, 0.020557] |
| two_stage | final_accuracy | 0.0028333 | [-0.0025224, 0.0081891] |
| two_stage | mean_objective | -0.015506 | [-0.14836, 0.11735] |
| two_stage | success_ratio | -0.0066667 | [-0.060622, 0.047289] |
| two_stage | bytes_ratio | 0.03 | [-0.05328, 0.11328] |
| two_stage | brier | 0.00049113 | [-0.041613, 0.042596] |
| two_stage | ece | -0.01651 | [-0.068574, 0.035553] |

## high_mobility

| Baseline | Metric | GCDP - baseline | 95% CI |
|---|---|---:|---|
| compression_only | final_accuracy | -0.0036667 | [-0.010152, 0.0028189] |
| compression_only | mean_objective | 1.0503 | [0.74461, 1.3561] |
| compression_only | success_ratio | -0.046667 | [-0.11591, 0.022579] |
| compression_only | bytes_ratio | -0.88 | [-1.016, -0.744] |
| compression_only | brier | 0.028406 | [-0.012915, 0.069727] |
| compression_only | ece | 0.044115 | [-0.027671, 0.1159] |
| fedavg | final_accuracy | 0.63233 | [0.55664, 0.70802] |
| fedavg | mean_objective | 3.3983 | [3.0951, 3.7014] |
| fedavg | success_ratio | 0.86667 | [0.7839, 0.94943] |
| fedavg | bytes_ratio | 2.87 | [2.734, 3.006] |
| fedavg | brier | nan | [nan, nan] |
| fedavg | ece | nan | [nan, nan] |
| fixed_aead | final_accuracy | -0.010667 | [-0.014766, -0.0065674] |
| fixed_aead | mean_objective | 2.5459 | [1.999, 3.0927] |
| fixed_aead | success_ratio | -0.02 | [-0.095174, 0.055174] |
| fixed_aead | bytes_ratio | -27.13 | [-27.266, -26.994] |
| fixed_aead | brier | 0.020525 | [-0.0038375, 0.044888] |
| fixed_aead | ece | -0.0032812 | [-0.079604, 0.073042] |
| fixed_secagg | final_accuracy | -0.0068333 | [-0.010217, -0.0034492] |
| fixed_secagg | mean_objective | -0.046036 | [-0.60714, 0.51507] |
| fixed_secagg | success_ratio | 0.0066667 | [-0.14927, 0.16261] |
| fixed_secagg | bytes_ratio | -0.88 | [-1.016, -0.744] |
| fixed_secagg | brier | 0.0036816 | [-0.067494, 0.074858] |
| fixed_secagg | ece | 0.010833 | [-0.094394, 0.11606] |
| greedy_repair | final_accuracy | 0 | [0, 0] |
| greedy_repair | mean_objective | 8.8818e-17 | [-1.5774e-16, 3.3538e-16] |
| greedy_repair | success_ratio | 0 | [0, 0] |
| greedy_repair | bytes_ratio | -8.8818e-17 | [-3.3538e-16, 1.5774e-16] |
| greedy_repair | brier | 0 | [0, 0] |
| greedy_repair | ece | 0 | [0, 0] |
| reactive | final_accuracy | -0.0031667 | [-0.0099665, 0.0036331] |
| reactive | mean_objective | 1.0453 | [0.74321, 1.3475] |
| reactive | success_ratio | -0.04 | [-0.1196, 0.0396] |
| reactive | bytes_ratio | -1.33 | [-1.815, -0.84499] |
| reactive | brier | 0.022479 | [-0.026639, 0.071597] |
| reactive | ece | 0.039271 | [-0.036416, 0.11496] |
| two_stage | final_accuracy | -0.00083333 | [-0.0085058, 0.0068391] |
| two_stage | mean_objective | 0.16784 | [0.10008, 0.23559] |
| two_stage | success_ratio | 0.086667 | [0.049653, 0.12368] |
| two_stage | bytes_ratio | -0.04 | [-0.12093, 0.040934] |
| two_stage | brier | -0.031021 | [-0.059206, -0.002835] |
| two_stage | ece | -0.025104 | [-0.092026, 0.041818] |

## large_secagg_group

| Baseline | Metric | GCDP - baseline | 95% CI |
|---|---|---:|---|
| compression_only | final_accuracy | -0.00066667 | [-0.015213, 0.01388] |
| compression_only | mean_objective | 1.2434 | [1.1224, 1.3644] |
| compression_only | success_ratio | 0.02 | [-0.03552, 0.07552] |
| compression_only | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| compression_only | brier | -0.011937 | [-0.05872, 0.034847] |
| compression_only | ece | -0.011146 | [-0.058168, 0.035877] |
| fedavg | final_accuracy | 0.63867 | [0.56501, 0.71232] |
| fedavg | mean_objective | 3.5268 | [3.3528, 3.7007] |
| fedavg | success_ratio | 0.84667 | [0.71386, 0.97948] |
| fedavg | bytes_ratio | 2.99 | [2.8178, 3.1622] |
| fedavg | brier | nan | [nan, nan] |
| fedavg | ece | nan | [nan, nan] |
| fixed_aead | final_accuracy | 0.0013333 | [-0.017835, 0.020502] |
| fixed_aead | mean_objective | 2.5315 | [2.1564, 2.9067] |
| fixed_aead | success_ratio | -0.026667 | [-0.11638, 0.063048] |
| fixed_aead | bytes_ratio | -27.01 | [-27.182, -26.838] |
| fixed_aead | brier | 0.017507 | [-0.043605, 0.078618] |
| fixed_aead | ece | 0.020208 | [-0.053878, 0.094295] |
| fixed_secagg | final_accuracy | -0.0013333 | [-0.012418, 0.0097514] |
| fixed_secagg | mean_objective | 0.12142 | [-0.034109, 0.27695] |
| fixed_secagg | success_ratio | 0.0066667 | [-0.061331, 0.074665] |
| fixed_secagg | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| fixed_secagg | brier | -0.0054622 | [-0.062813, 0.051888] |
| fixed_secagg | ece | -0.010104 | [-0.037276, 0.017068] |
| greedy_repair | final_accuracy | 0.0031667 | [-0.005624, 0.011957] |
| greedy_repair | mean_objective | 0.00030337 | [-0.00053878, 0.0011455] |
| greedy_repair | success_ratio | 0.0066667 | [-0.01184, 0.025173] |
| greedy_repair | bytes_ratio | 0.01 | [-0.01776, 0.03776] |
| greedy_repair | brier | -0.0047416 | [-0.017904, 0.0084211] |
| greedy_repair | ece | 0.0025521 | [-0.0045325, 0.0096367] |
| reactive | final_accuracy | -0.00083333 | [-0.016108, 0.014442] |
| reactive | mean_objective | 1.2333 | [1.1083, 1.3584] |
| reactive | success_ratio | 0.026667 | [-0.027289, 0.080622] |
| reactive | bytes_ratio | -1.39 | [-1.8358, -0.94422] |
| reactive | brier | -0.017871 | [-0.061488, 0.025745] |
| reactive | ece | -0.016562 | [-0.053682, 0.020557] |
| two_stage | final_accuracy | 0.0028333 | [-0.0025224, 0.0081891] |
| two_stage | mean_objective | -0.015506 | [-0.14836, 0.11735] |
| two_stage | success_ratio | -0.0066667 | [-0.060622, 0.047289] |
| two_stage | bytes_ratio | 0.03 | [-0.05328, 0.11328] |
| two_stage | brier | 0.00049113 | [-0.041613, 0.042596] |
| two_stage | ece | -0.01651 | [-0.068574, 0.035553] |

## low_exposure_budget

| Baseline | Metric | GCDP - baseline | 95% CI |
|---|---|---:|---|
| compression_only | final_accuracy | -0.00066667 | [-0.015213, 0.01388] |
| compression_only | mean_objective | 1.2434 | [1.1224, 1.3644] |
| compression_only | success_ratio | 0.02 | [-0.03552, 0.07552] |
| compression_only | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| compression_only | brier | -0.011937 | [-0.05872, 0.034847] |
| compression_only | ece | -0.011146 | [-0.058168, 0.035877] |
| fedavg | final_accuracy | 0.63867 | [0.56501, 0.71232] |
| fedavg | mean_objective | 3.5268 | [3.3528, 3.7007] |
| fedavg | success_ratio | 0.84667 | [0.71386, 0.97948] |
| fedavg | bytes_ratio | 2.99 | [2.8178, 3.1622] |
| fedavg | brier | nan | [nan, nan] |
| fedavg | ece | nan | [nan, nan] |
| fixed_aead | final_accuracy | 0.0013333 | [-0.017835, 0.020502] |
| fixed_aead | mean_objective | 2.5315 | [2.1564, 2.9067] |
| fixed_aead | success_ratio | -0.026667 | [-0.11638, 0.063048] |
| fixed_aead | bytes_ratio | -27.01 | [-27.182, -26.838] |
| fixed_aead | brier | 0.017507 | [-0.043605, 0.078618] |
| fixed_aead | ece | 0.020208 | [-0.053878, 0.094295] |
| fixed_secagg | final_accuracy | -0.0013333 | [-0.012418, 0.0097514] |
| fixed_secagg | mean_objective | 0.12142 | [-0.034109, 0.27695] |
| fixed_secagg | success_ratio | 0.0066667 | [-0.061331, 0.074665] |
| fixed_secagg | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| fixed_secagg | brier | -0.0054622 | [-0.062813, 0.051888] |
| fixed_secagg | ece | -0.010104 | [-0.037276, 0.017068] |
| greedy_repair | final_accuracy | 0.0031667 | [-0.005624, 0.011957] |
| greedy_repair | mean_objective | 0.00030337 | [-0.00053878, 0.0011455] |
| greedy_repair | success_ratio | 0.0066667 | [-0.01184, 0.025173] |
| greedy_repair | bytes_ratio | 0.01 | [-0.01776, 0.03776] |
| greedy_repair | brier | -0.0047416 | [-0.017904, 0.0084211] |
| greedy_repair | ece | 0.0025521 | [-0.0045325, 0.0096367] |
| reactive | final_accuracy | -0.00083333 | [-0.016108, 0.014442] |
| reactive | mean_objective | 1.2333 | [1.1083, 1.3584] |
| reactive | success_ratio | 0.026667 | [-0.027289, 0.080622] |
| reactive | bytes_ratio | -1.39 | [-1.8358, -0.94422] |
| reactive | brier | -0.017871 | [-0.061488, 0.025745] |
| reactive | ece | -0.016562 | [-0.053682, 0.020557] |
| two_stage | final_accuracy | 0.0028333 | [-0.0025224, 0.0081891] |
| two_stage | mean_objective | -0.015506 | [-0.14836, 0.11735] |
| two_stage | success_ratio | -0.0066667 | [-0.060622, 0.047289] |
| two_stage | bytes_ratio | 0.03 | [-0.05328, 0.11328] |
| two_stage | brier | 0.00049113 | [-0.041613, 0.042596] |
| two_stage | ece | -0.01651 | [-0.068574, 0.035553] |

## nominal

| Baseline | Metric | GCDP - baseline | 95% CI |
|---|---|---:|---|
| compression_only | final_accuracy | -0.00066667 | [-0.015213, 0.01388] |
| compression_only | mean_objective | 1.2434 | [1.1224, 1.3644] |
| compression_only | success_ratio | 0.02 | [-0.03552, 0.07552] |
| compression_only | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| compression_only | brier | -0.011937 | [-0.05872, 0.034847] |
| compression_only | ece | -0.011146 | [-0.058168, 0.035877] |
| fedavg | final_accuracy | 0.63867 | [0.56501, 0.71232] |
| fedavg | mean_objective | 3.5268 | [3.3528, 3.7007] |
| fedavg | success_ratio | 0.84667 | [0.71386, 0.97948] |
| fedavg | bytes_ratio | 2.99 | [2.8178, 3.1622] |
| fedavg | brier | nan | [nan, nan] |
| fedavg | ece | nan | [nan, nan] |
| fixed_aead | final_accuracy | 0.0013333 | [-0.017835, 0.020502] |
| fixed_aead | mean_objective | 2.5315 | [2.1564, 2.9067] |
| fixed_aead | success_ratio | -0.026667 | [-0.11638, 0.063048] |
| fixed_aead | bytes_ratio | -27.01 | [-27.182, -26.838] |
| fixed_aead | brier | 0.017507 | [-0.043605, 0.078618] |
| fixed_aead | ece | 0.020208 | [-0.053878, 0.094295] |
| fixed_secagg | final_accuracy | -0.0013333 | [-0.012418, 0.0097514] |
| fixed_secagg | mean_objective | 0.12142 | [-0.034109, 0.27695] |
| fixed_secagg | success_ratio | 0.0066667 | [-0.061331, 0.074665] |
| fixed_secagg | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| fixed_secagg | brier | -0.0054622 | [-0.062813, 0.051888] |
| fixed_secagg | ece | -0.010104 | [-0.037276, 0.017068] |
| greedy_repair | final_accuracy | 0.0031667 | [-0.005624, 0.011957] |
| greedy_repair | mean_objective | 0.00030337 | [-0.00053878, 0.0011455] |
| greedy_repair | success_ratio | 0.0066667 | [-0.01184, 0.025173] |
| greedy_repair | bytes_ratio | 0.01 | [-0.01776, 0.03776] |
| greedy_repair | brier | -0.0047416 | [-0.017904, 0.0084211] |
| greedy_repair | ece | 0.0025521 | [-0.0045325, 0.0096367] |
| reactive | final_accuracy | -0.00083333 | [-0.016108, 0.014442] |
| reactive | mean_objective | 1.2333 | [1.1083, 1.3584] |
| reactive | success_ratio | 0.026667 | [-0.027289, 0.080622] |
| reactive | bytes_ratio | -1.39 | [-1.8358, -0.94422] |
| reactive | brier | -0.017871 | [-0.061488, 0.025745] |
| reactive | ece | -0.016562 | [-0.053682, 0.020557] |
| two_stage | final_accuracy | 0.0028333 | [-0.0025224, 0.0081891] |
| two_stage | mean_objective | -0.015506 | [-0.14836, 0.11735] |
| two_stage | success_ratio | -0.0066667 | [-0.060622, 0.047289] |
| two_stage | bytes_ratio | 0.03 | [-0.05328, 0.11328] |
| two_stage | brier | 0.00049113 | [-0.041613, 0.042596] |
| two_stage | ece | -0.01651 | [-0.068574, 0.035553] |

## tight_deadline

| Baseline | Metric | GCDP - baseline | 95% CI |
|---|---|---:|---|
| compression_only | final_accuracy | -0.00066667 | [-0.015213, 0.01388] |
| compression_only | mean_objective | 1.2434 | [1.1224, 1.3644] |
| compression_only | success_ratio | 0.02 | [-0.03552, 0.07552] |
| compression_only | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| compression_only | brier | -0.011937 | [-0.05872, 0.034847] |
| compression_only | ece | -0.011146 | [-0.058168, 0.035877] |
| fedavg | final_accuracy | 0.63867 | [0.56501, 0.71232] |
| fedavg | mean_objective | 3.5268 | [3.3528, 3.7007] |
| fedavg | success_ratio | 0.84667 | [0.71386, 0.97948] |
| fedavg | bytes_ratio | 2.99 | [2.8178, 3.1622] |
| fedavg | brier | nan | [nan, nan] |
| fedavg | ece | nan | [nan, nan] |
| fixed_aead | final_accuracy | 0.0013333 | [-0.017835, 0.020502] |
| fixed_aead | mean_objective | 2.5315 | [2.1564, 2.9067] |
| fixed_aead | success_ratio | -0.026667 | [-0.11638, 0.063048] |
| fixed_aead | bytes_ratio | -27.01 | [-27.182, -26.838] |
| fixed_aead | brier | 0.017507 | [-0.043605, 0.078618] |
| fixed_aead | ece | 0.020208 | [-0.053878, 0.094295] |
| fixed_secagg | final_accuracy | -0.0013333 | [-0.012418, 0.0097514] |
| fixed_secagg | mean_objective | 0.12142 | [-0.034109, 0.27695] |
| fixed_secagg | success_ratio | 0.0066667 | [-0.061331, 0.074665] |
| fixed_secagg | bytes_ratio | -0.76 | [-0.93225, -0.58775] |
| fixed_secagg | brier | -0.0054622 | [-0.062813, 0.051888] |
| fixed_secagg | ece | -0.010104 | [-0.037276, 0.017068] |
| greedy_repair | final_accuracy | 0.0031667 | [-0.005624, 0.011957] |
| greedy_repair | mean_objective | 0.00030337 | [-0.00053878, 0.0011455] |
| greedy_repair | success_ratio | 0.0066667 | [-0.01184, 0.025173] |
| greedy_repair | bytes_ratio | 0.01 | [-0.01776, 0.03776] |
| greedy_repair | brier | -0.0047416 | [-0.017904, 0.0084211] |
| greedy_repair | ece | 0.0025521 | [-0.0045325, 0.0096367] |
| reactive | final_accuracy | -0.00083333 | [-0.016108, 0.014442] |
| reactive | mean_objective | 1.2333 | [1.1083, 1.3584] |
| reactive | success_ratio | 0.026667 | [-0.027289, 0.080622] |
| reactive | bytes_ratio | -1.39 | [-1.8358, -0.94422] |
| reactive | brier | -0.017871 | [-0.061488, 0.025745] |
| reactive | ece | -0.016562 | [-0.053682, 0.020557] |
| two_stage | final_accuracy | 0.0028333 | [-0.0025224, 0.0081891] |
| two_stage | mean_objective | -0.015506 | [-0.14836, 0.11735] |
| two_stage | success_ratio | -0.0066667 | [-0.060622, 0.047289] |
| two_stage | bytes_ratio | 0.03 | [-0.05328, 0.11328] |
| two_stage | brier | 0.00049113 | [-0.041613, 0.042596] |
| two_stage | ece | -0.01651 | [-0.068574, 0.035553] |
