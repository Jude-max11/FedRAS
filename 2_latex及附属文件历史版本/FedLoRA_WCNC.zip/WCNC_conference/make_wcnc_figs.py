"""Regenerate the two evaluation figures for the WCNC conference version
from the canonical experiment data (single-column legible sizing).
Legends are placed OUTSIDE the axes so they never cover the curves."""
import os
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
plt.rcParams.update({'font.size': 9, 'axes.grid': True, 'grid.alpha': .3,
                     'axes.linewidth': .8, 'figure.dpi': 200, 'savefig.bbox': 'tight'})

STYLE = {
    'FedAvg_full':    ('FedAvg (full)', '#c0392b', '-', 1.5),
    'FedAvg':         ('FedAvg (full)', '#c0392b', '-', 1.5),
    'FedLoRA_r4':     ('FedLoRA r=4',   '#7f8c8d', '-', 1.1),
    'FedLoRA_r16':    ('FedLoRA r=16',  '#2980b9', '-', 1.1),
    'Random_rank':    ('Random rank',   '#8e44ad', '-', 1.1),
    'Reliability_only': ('Reliability-only', '#f39c12', '-', 1.1),
    'SA_rank':        ('SA-annealing',  '#e67e22', '--', 1.2),
    'Adaptive_rank':  ('Adaptive (ours)', '#27ae60', '-', 1.6),
}

def legend_below(ax, ncol):
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.30), ncol=ncol,
              fontsize=6.5, frameon=False, columnspacing=0.9,
              handlelength=1.5, handletextpad=0.4)

# ---- Fig: real trainer under the 0.25 s deadline (CIFAR-10, five seeds) ----
d = pd.read_csv(os.path.join(ROOT, 'outputs/real_fedlora_v3/all_metrics.csv'))
g = d[d.dataset == 'cifar10_dl0.25']
fig, ax = plt.subplots(figsize=(3.6, 1.45))
for m in ['FedAvg_full', 'FedLoRA_r4', 'FedLoRA_r16', 'Random_rank', 'Adaptive_rank']:
    label, color, ls, lw = STYLE[m]
    z = g[g['method'] == m].groupby('round')['accuracy'].agg(['mean', 'std'])
    ax.plot(z.index, z['mean'], label=label, color=color, ls=ls, lw=lw)
    ax.fill_between(z.index, z['mean'] - z['std'], z['mean'] + z['std'], alpha=.12, color=color)
ax.set_xlabel('Communication round')
ax.set_ylabel('Test accuracy')
ax.set_ylim(0.910, 0.917)
ax.set_xlim(0, 39)
legend_below(ax, 3)
fig.savefig(os.path.join(HERE, 'fig_trainer_stress.png'))
plt.close(fig)

# ---- Fig: 500-client scheduler simulation, 0.25 s deadline ----
d = pd.read_csv(os.path.join(ROOT, 'outputs/paper_sweep/all_round_metrics.csv'))
g = d[d.scenario == 'stress/deadline_025']
fig, ax = plt.subplots(figsize=(3.6, 1.6))
for m in ['FedAvg', 'FedLoRA_r4', 'FedLoRA_r16', 'Random_rank', 'Reliability_only', 'SA_rank', 'Adaptive_rank']:
    label, color, ls, lw = STYLE[m]
    z = g[g['method'] == m].groupby('round')['accuracy'].agg(['mean', 'std'])
    ax.plot(z.index, z['mean'], label=label, color=color, ls=ls, lw=lw)
    ax.fill_between(z.index, z['mean'] - z['std'], z['mean'] + z['std'], alpha=.10, color=color)
ax.set_xlabel('Communication round')
ax.set_ylabel('Scheduling accuracy (proxy)')
ax.set_xlim(0, 149)
legend_below(ax, 3)
fig.savefig(os.path.join(HERE, 'fig_sim_stress.png'))
plt.close(fig)

print('written: fig_trainer_stress.png, fig_sim_stress.png')
