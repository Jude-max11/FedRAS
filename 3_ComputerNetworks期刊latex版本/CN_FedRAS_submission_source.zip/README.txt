FedRAS 投稿源码包（Computer Networks，Elsevier cas-dc 双栏模板）
================================================================

一、文件结构
----------
CN_reviewed.tex              正文 —— 唯一需要编辑的文件
CN_reviewed.bbl              参考文献编译产物（不重跑 bibtex 也能直接编译）
references.bib               参考文献数据库（增删文献时编辑这个）
CN_reviewed_compiled.pdf     当前成品 PDF（供对照）
cas-dc.cls / cas-common.sty  Elsevier CAS 文档类（已内置，机器上无需安装 els-cas 模板）
elsarticle-num.bst           参考文献样式（已内置）
recolored_figures/
    1.png                    图 1：手绘架构图（跨栏）
    panels/*.pdf             图 2-9 的全部图件（0 白边矢量 PDF，共 22 个）
    panels/*_legend.pdf      共享图例条（图 2、图 6、图 7、图 8 各一条）

二、如何编译（pdfLaTeX）
----------
    pdflatex CN_reviewed.tex
    bibtex  CN_reviewed
    pdflatex CN_reviewed.tex
    pdflatex CN_reviewed.tex

没有改动参考文献时可跳过 bibtex（.bbl 已附带）。
Overleaf：New Project -> Upload Project 直接上传本 zip，编译器选 pdfLaTeX。
本地：TeX Live 完整版或 MiKTeX 均可；CAS 文档类与 bst 已内置，不会缺模板。

三、编辑提示
----------
- 各子图的 (a)(b)(c) 小标题和每个图的总标题都写在 CN_reviewed.tex 的
  figure 环境内（\subfloat），不在图片内部。
- 图件是 0 白边矢量 PDF；每个子图的宽度按行宽配平（写成 \linewidth 的百分比）。
  改文字不动图；若确需调整图宽，请同步微调同一行各子图的百分比使总和约 0.98。
- 共享图例条（*_legend.pdf）只出现一次，位于对应子图行上方，删除或改动前
  请确认对应面板内已无图例。
- 新增 \cite 后需重跑 bibtex；引用键与 references.bib 一一对应（41 条）。
- 交叉引用统一用 \ref/\eqref（图、表、公式、命题、算法），cas-dc 下编号自动处理。
